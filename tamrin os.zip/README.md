# OS-Exercises
 Answers to the exercises of operating system of Shiraz University of Technology
